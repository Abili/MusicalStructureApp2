package com.raisac.musicalstructureapp;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MusicAdapter extends ArrayAdapter<Music> {
    public MusicAdapter(@NonNull Activity context, ArrayList<Music> music) {
        super(context, 0, music);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View musicView = convertView;
        if(musicView==null) {
            musicView = LayoutInflater.from(getContext()).inflate(R.layout.music_item, parent, false);
        }

        Music music = getItem(position);
        TextView songname = musicView.findViewById(R.id.song_name);
        songname.setText(music.getSongName());
        return musicView;
    }
}
